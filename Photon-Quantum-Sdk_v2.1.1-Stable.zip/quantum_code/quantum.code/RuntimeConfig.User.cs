﻿using Photon.Deterministic;
using System;

namespace Quantum {
  partial class RuntimeConfig {
  }
}