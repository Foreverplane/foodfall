﻿using UnityEngine;

public class MapNavMeshUnity : MonoBehaviour {
  public GameObject[] NavMeshSurfaces;
  public MapNavMesh.ImportSettings Settings;
}
